function resimler(a)
{
        
    if(a="r1")
    {
        document.getElementsByClassName("resim").innerHTML+="<img src='resimler/1.jpg' width='400px' heigth='400px'></img>"
    }

    
     if(a=="r2")
    {
        document.getElementsByClassName("resim").innerHTML+="<img src='resimler/2.jpg' width='400px' heigth='400px'></img>"
    }
    if(a="r3")
    {
        document.getElementsByClassName("resim").innerHTML+="<img src='resimler/3.jpg' width='400px' heigth='400px'></img>"
    }
}